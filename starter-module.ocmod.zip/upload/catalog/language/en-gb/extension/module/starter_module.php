<?php
// Heading
$_['heading_title'] = 'Starter Module';